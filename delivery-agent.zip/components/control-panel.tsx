"use client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"

interface ControlPanelProps {
  onMapSelect: (mapName: string) => void
  onAlgorithmSelect: (algorithm: string) => void
  onStartChange: (start: string) => void
  onGoalChange: (goal: string) => void
  onSimulate: () => void
  onToggleDynamicReplanning: (checked: boolean) => void
  dynamicReplanningEnabled: boolean
  currentMap: string
  currentAlgorithm: string
  startCoords: string
  goalCoords: string
}

export function ControlPanel({
  onMapSelect,
  onAlgorithmSelect,
  onStartChange,
  onGoalChange,
  onSimulate,
  onToggleDynamicReplanning,
  dynamicReplanningEnabled,
  currentMap,
  currentAlgorithm,
  startCoords,
  goalCoords,
}: ControlPanelProps) {
  return (
    <div className="bg-card p-6 rounded-lg shadow-lg w-full max-w-md space-y-4">
      <h2 className="text-2xl font-bold text-center">Simulation Controls</h2>

      <div>
        <Label htmlFor="map-select">Select Map</Label>
        <Select onValueChange={onMapSelect} value={currentMap}>
          <SelectTrigger id="map-select" className="w-full">
            <SelectValue placeholder="Select a map" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="small_map">Small Map</SelectItem>
            <SelectItem value="medium_map">Medium Map</SelectItem>
            <SelectItem value="large_map">Large Map</SelectItem>
            <SelectItem value="dynamic_map">Dynamic Map</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div>
        <Label htmlFor="algorithm-select">Select Algorithm</Label>
        <Select onValueChange={onAlgorithmSelect} value={currentAlgorithm}>
          <SelectTrigger id="algorithm-select" className="w-full">
            <SelectValue placeholder="Select an algorithm" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="UCS">Uniform-Cost Search (UCS)</SelectItem>
            <SelectItem value="A_STAR">A* Search</SelectItem>
            <SelectItem value="LOCAL_SEARCH">Local Search Replanning</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div>
        <Label htmlFor="start-coords">Start Coordinates (x,y)</Label>
        <Input
          id="start-coords"
          type="text"
          placeholder="e.g., 0,0"
          value={startCoords}
          onChange={(e) => onStartChange(e.target.value)}
        />
      </div>

      <div>
        <Label htmlFor="goal-coords">Goal Coordinates (x,y)</Label>
        <Input
          id="goal-coords"
          type="text"
          placeholder="e.g., 14,14"
          value={goalCoords}
          onChange={(e) => onGoalChange(e.target.value)}
        />
      </div>

      <div className="flex items-center space-x-2">
        <Checkbox
          id="dynamic-replanning"
          checked={dynamicReplanningEnabled}
          onCheckedChange={(checked) => onToggleDynamicReplanning(checked as boolean)}
          disabled={currentAlgorithm !== "LOCAL_SEARCH"}
        />
        <Label htmlFor="dynamic-replanning">Enable Dynamic Replanning (Local Search only)</Label>
      </div>

      <Button onClick={onSimulate} className="w-full">
        Run Simulation
      </Button>
    </div>
  )
}
