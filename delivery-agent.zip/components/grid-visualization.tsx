"use client"

import { useState, useEffect } from "react"

interface GridVisualizationProps {
  gridData: number[][] // Made gridData required
  staticObstacles?: { x: number; y: number }[]
  agentPosition?: { x: number; y: number }
  path?: { x: number; y: number }[]
  dynamicObstacles?: { x: number; y: number; time: number }[]
  currentTime?: number
}

export function GridVisualization({
  gridData, // gridData is now required
  staticObstacles = [],
  agentPosition,
  path = [],
  dynamicObstacles = [],
  currentTime = 0,
}: GridVisualizationProps) {
  const [grid, setGrid] = useState<number[][]>(gridData) // Initialize grid with gridData
  const [rows, setRows] = useState(gridData.length) // Initialize rows with gridData length
  const [cols, setCols] = useState(gridData[0]?.length || 0) // Initialize cols with gridData[0] length

  useEffect(() => {
    setGrid(gridData)
    setRows(gridData.length)
    setCols(gridData[0]?.length || 0)
  }, [gridData])

  const getCellColor = (x: number, y: number) => {
    const isStaticObstacle = staticObstacles.some((obs) => obs.x === x && obs.y === y)
    const isDynamicObstacle = dynamicObstacles.some((obs) => obs.x === x && obs.y === y && obs.time === currentTime)
    const isAgent = agentPosition && agentPosition.x === x && agentPosition.y === y
    const isOnPath = path.some((p) => p.x === x && p.y === y)

    if (isAgent) return "bg-blue-500"
    if (isStaticObstacle || isDynamicObstacle) return "bg-red-500"
    if (isOnPath) return "bg-green-400"

    const cost = grid[x]?.[y]
    switch (cost) {
      case 1:
        return "bg-gray-100 dark:bg-gray-800"
      case 2:
        return "bg-gray-300 dark:bg-gray-700"
      case 3:
        return "bg-gray-500 dark:bg-gray-600"
      default:
        return "bg-gray-100 dark:bg-gray-800"
    }
  }

  return (
    <div
      className="grid border border-border"
      style={{
        gridTemplateColumns: `repeat(${cols}, minmax(0, 1fr))`,
        gridTemplateRows: `repeat(${rows}, minmax(0, 1fr))`,
      }}
    >
      {grid.map((row, rowIndex) =>
        row.map((cell, colIndex) => (
          <div
            key={`${rowIndex}-${colIndex}`}
            className={`w-6 h-6 flex items-center justify-center text-xs border border-border ${getCellColor(
              rowIndex,
              colIndex,
            )}`}
          >
            {/* {cell} */}
          </div>
        )),
      )}
    </div>
  )
}
