import heapq
import random
from collections import deque
from delivery_agent import State # Import State for local search

def uniform_cost_search(agent):
    """
    Implements the Uniform-Cost Search (UCS) algorithm to find the lowest-cost path.

    Args:
        agent (DeliveryAgent): The delivery agent instance.

    Returns:
        tuple: (path, total_cost, nodes_expanded)
               path is a list of State objects from start to goal.
               total_cost is the accumulated cost of the path.
               nodes_expanded is the number of nodes popped from the priority queue.
               Returns (None, float('inf'), nodes_expanded) if no path is found.
    """
    start_state = agent.get_initial_state()
    
    # Priority queue: (cost, state, path)
    # path is a list of states from start to current
    priority_queue = [(0, start_state, [start_state])]
    
    # Dictionary to store the minimum cost to reach a state
    # Key: (x, y, time), Value: cost
    cost_so_far = { (start_state.x, start_state.y, start_state.time): 0 }
    
    nodes_expanded = 0

    while priority_queue:
        current_cost, current_state, current_path = heapq.heappop(priority_queue)
        nodes_expanded += 1

        if agent.is_goal(current_state):
            return current_path, current_cost, nodes_expanded

        for next_state in agent.get_actions(current_state):
            # Calculate the cost to move to the next state
            move_cost = agent.get_cost(current_state, next_state)
            new_cost = current_cost + move_cost
            
            # Check if this path to next_state is cheaper than any previously found path
            if (next_state.x, next_state.y, next_state.time) not in cost_so_far or new_cost < cost_so_far[(next_state.x, next_state.y, next_state.time)]:
                cost_so_far[(next_state.x, next_state.y, next_state.time)] = new_cost
                new_path = current_path + [next_state]
                heapq.heappush(priority_queue, (new_cost, next_state, new_path))
    
    return None, float('inf'), nodes_expanded # No path found

def manhattan_distance_heuristic(state, goal_position):
    """
    Calculates the Manhattan distance heuristic from the current state to the goal.
    Assumes minimum terrain cost is 1, making it admissible for 4-connected movement.
    """
    return abs(state.x - goal_position[0]) + abs(state.y - goal_position[1])

def a_star_search(agent, heuristic_func):
    """
    Implements the A* Search algorithm to find the lowest-cost path using a heuristic.

    Args:
        agent (DeliveryAgent): The delivery agent instance.
        heuristic_func (function): An admissible heuristic function (e.g., manhattan_distance_heuristic).

    Returns:
        tuple: (path, total_cost, nodes_expanded)
               path is a list of State objects from start to goal.
               total_cost is the accumulated cost of the path.
               nodes_expanded is the number of nodes popped from the priority queue.
               Returns (None, float('inf'), nodes_expanded) if no path is found.
    """
    start_state = agent.get_initial_state()
    
    # Priority queue: (f_cost, current_cost, state, path)
    # f_cost = current_cost + heuristic_value
    priority_queue = [(heuristic_func(start_state, agent.goal_position), 0, start_state, [start_state])]
    
    # Dictionary to store the minimum cost to reach a state
    # Key: (x, y, time), Value: cost
    cost_so_far = { (start_state.x, start_state.y, start_state.time): 0 }
    
    nodes_expanded = 0

    while priority_queue:
        f_cost, current_cost, current_state, current_path = heapq.heappop(priority_queue)
        nodes_expanded += 1

        if agent.is_goal(current_state):
            return current_path, current_cost, nodes_expanded

        for next_state in agent.get_actions(current_state):
            move_cost = agent.get_cost(current_state, next_state)
            new_cost = current_cost + move_cost
            
            if (next_state.x, next_state.y, next_state.time) not in cost_so_far or new_cost < cost_so_far[(next_state.x, next_state.y, next_state.time)]:
                cost_so_far[(next_state.x, next_state.y, next_state.time)] = new_cost
                new_path = current_path + [next_state]
                heuristic_value = heuristic_func(next_state, agent.goal_position)
                heapq.heappush(priority_queue, (new_cost + heuristic_value, new_cost, next_state, new_path))
    
    return None, float('inf'), nodes_expanded # No path found

def evaluate_path(agent, path):
    """
    Evaluates the total cost of a given path, considering terrain costs and dynamic obstacles.
    Returns float('inf') if the path is invalid (e.g., hits an obstacle or does not reach goal).
    """
    total_cost = 0
    if not path:
        return float('inf')

    for i in range(len(path) - 1):
        current_state = path[i]
        next_state = path[i+1]

        # Check for dynamic obstacles at the time of entering the next state
        if agent.environment.is_obstacle(next_state.x, next_state.y, next_state.time):
            return float('inf')
        
        # Check for static obstacles (no time argument needed for static check)
        if agent.environment.is_obstacle(next_state.x, next_state.y): 
             return float('inf')

        total_cost += agent.get_cost(current_state, next_state)
    
    # Check if the final state is the goal
    if not agent.is_goal(path[-1]):
        return float('inf')

    return total_cost

def generate_random_path(agent, start_state, max_length=100):
    """
    Generates a random path from start_state towards the goal, avoiding immediate obstacles.
    Used as an initial solution for local search.
    """
    path = [start_state]
    current = start_state
    
    for _ in range(max_length):
        if agent.is_goal(current):
            break
        
        possible_next_states = []
        for nx, ny in agent.environment.get_neighbors(current.x, current.y):
            next_time = current.time + 1
            if not agent.environment.is_obstacle(nx, ny, next_time):
                possible_next_states.append(State(x=nx, y=ny, time=next_time))
        
        if not possible_next_states:
            return None # Stuck, cannot move further
        
        current = random.choice(possible_next_states)
        path.append(current)
    
    if agent.is_goal(current):
        return path
    return None

def hill_climbing_replanning(agent, current_agent_state, max_iterations=100, restarts=5, path_length_limit=50):
    """
    Implements hill climbing with random restarts for replanning in dynamic environments.
    It attempts to find a path from the current_agent_state to the goal.

    Args:
        agent (DeliveryAgent): The delivery agent instance.
        current_agent_state (State): The agent's current (x, y, time) state.
        max_iterations (int): Maximum number of improvement attempts per restart.
        restarts (int): Number of random restarts to try to escape local optima.
        path_length_limit (int): Maximum length for randomly generated paths.

    Returns:
        tuple: (path, total_cost, nodes_expanded)
               path is a list of State objects from current_agent_state to goal.
               total_cost is the accumulated cost of the path.
               nodes_expanded is the number of path evaluations performed.
               Returns (None, float('inf'), nodes_expanded) if no suitable path is found.
    """
    best_path = None
    best_cost = float('inf')
    nodes_expanded = 0 # For local search, this is more about path evaluations

    for _ in range(restarts):
        # Generate an initial random path from the current agent state
        current_path = generate_random_path(agent, current_agent_state, max_length=path_length_limit)
        if current_path is None:
            continue # Could not generate a valid initial path

        current_cost = evaluate_path(agent, current_path)
        nodes_expanded += 1

        if current_cost < best_cost:
            best_cost = current_cost
            best_path = current_path

        for _ in range(max_iterations):
            if best_cost == float('inf'): # If current best path is invalid, try to find a new one
                current_path = generate_random_path(agent, current_agent_state, max_length=path_length_limit)
                if current_path is None:
                    break
                current_cost = evaluate_path(agent, current_path)
                nodes_expanded += 1
                if current_cost < best_cost:
                    best_cost = current_cost
                    best_path = current_path
                    continue

            # Try to find a better neighbor path
            improved = False
            
            # Mutation: change one step in the path
            if len(current_path) > 1:
                idx_to_change = random.randint(1, len(current_path) - 1)
                
                # Get the state before the change point
                pre_change_state = current_path[idx_to_change - 1]
                
                # Find possible next states from pre_change_state
                possible_next_steps = []
                for nx, ny in agent.environment.get_neighbors(pre_change_state.x, pre_change_state.y):
                    next_time = pre_change_state.time + 1
                    if not agent.environment.is_obstacle(nx, ny, next_time):
                        possible_next_steps.append(State(x=nx, y=ny, time=next_time))

                if possible_next_steps:
                    # Try replacing the step at idx_to_change with a new possible step
                    for new_next_step in possible_next_steps:
                        # Create a new path by replacing the step and then trying to connect to the goal
                        # This is a simplification for hill climbing. A more robust approach would
                        # involve re-planning the segment from new_next_step to the goal using A*.
                        
                        # For this basic hill climbing, we'll just try to connect the new step
                        # to the rest of the path or directly to the goal if it's the last step.
                        
                        new_path_candidate = list(current_path[:idx_to_change]) + [new_next_step]
                        
                        # If the new_next_step is not the goal, we need to extend it.
                        # For simplicity, we'll assume the rest of the path is still valid if it was before,
                        # or we'll rely on evaluate_path to penalize invalid paths.
                        # A more advanced local search would re-generate the path from new_next_step to goal.
                        
                        # If the new_next_step is the goal, we're done with this segment
                        if not agent.is_goal(new_next_step):
                            # If not the goal, try to append the remaining part of the original path
                            # This is a very naive way to "reconnect" and might often lead to invalid paths
                            # if the original path segment after idx_to_change is no longer valid.
                            # A better approach would be to run a small A* from new_next_step to agent.goal_position.
                            # For the scope of this basic hill climbing, we accept this limitation.
                            if idx_to_change + 1 < len(current_path):
                                new_path_candidate.extend(current_path[idx_to_change+1:])
                            else:
                                # If we changed the last step and it's not the goal, this path is likely invalid
                                pass # evaluate_path will handle this

                        new_cost = evaluate_path(agent, new_path_candidate)
                        nodes_expanded += 1

                        if new_cost < current_cost:
                            current_cost = new_cost
                            current_path = new_path_candidate
                            improved = True
                            if current_cost < best_cost:
                                best_cost = current_cost
                                best_path = current_path
                            break # Found an improvement, move to next iteration of hill climbing
            
            if not improved:
                break # No improvement found in this iteration, local optimum reached

    return best_path, best_cost, nodes_expanded
