from collections import namedtuple

# Define the agent's state as (x, y, time)
State = namedtuple('State', ['x', 'y', 'time'])

class DeliveryAgent:
    """
    Represents the autonomous delivery agent.

    Attributes:
        environment (GridEnvironment): The grid environment the agent operates in.
        start_position (tuple): The (x, y) coordinates of the agent's starting position.
        goal_position (tuple): The (x, y) coordinates of the delivery goal.
    """
    def __init__(self, environment, start_position, goal_position):
        self.environment = environment
        self.start_position = start_position
        self.goal_position = goal_position

    def get_initial_state(self):
        """
        Returns the agent's initial state.
        """
        return State(x=self.start_position[0], y=self.start_position[1], time=0)

    def is_goal(self, state):
        """
        Checks if the given state is the goal state.
        """
        return (state.x, state.y) == self.goal_position

    def get_actions(self, state):
        """
        Returns a list of possible next states (actions) from the current state.
        Each action is a move to an adjacent 4-connected cell, considering dynamic obstacles
        at the *next* time step.
        """
        actions = []
        current_time = state.time
        for nx, ny in self.environment.get_neighbors(state.x, state.y):
            # Check if the next position is an obstacle at the next time step
            if not self.environment.is_obstacle(nx, ny, current_time + 1):
                actions.append(State(x=nx, y=ny, time=current_time + 1))
        return actions

    def get_cost(self, current_state, next_state):
        """
        Returns the cost of moving from current_state to next_state.
        This is the terrain cost of the next_state.
        """
        return self.environment.get_cost(next_state.x, next_state.y)
