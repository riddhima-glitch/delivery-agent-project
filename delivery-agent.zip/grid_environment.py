import collections

class GridEnvironment:
    """
    Represents the 2D grid city environment for the delivery agent.

    Attributes:
        width (int): The width of the grid.
        height (int): The height of the grid.
        terrain_costs (dict): A dictionary mapping (x, y) coordinates to their movement cost.
                              Default cost is 1 if not specified.
        static_obstacles (set): A set of (x, y) coordinates representing impassable static obstacles.
        dynamic_obstacles_schedule (collections.defaultdict): A dictionary mapping time steps to a set of (x, y)
                                                              positions occupied by dynamic obstacles at that time.
    """
    def __init__(self, width, height, terrain_costs=None, static_obstacles=None, dynamic_obstacles_schedule=None):
        self.width = width
        self.height = height
        self.terrain_costs = terrain_costs if terrain_costs is not None else {}
        self.static_obstacles = static_obstacles if static_obstacles is not None else set()
        # dynamic_obstacles_schedule: {time: set of (x, y) positions}
        self.dynamic_obstacles_schedule = dynamic_obstacles_schedule if dynamic_obstacles_schedule is not None else collections.defaultdict(set)

    def get_cost(self, x, y):
        """
        Returns the movement cost of a specific grid cell.
        Returns float('inf') if the cell is out of bounds or a static obstacle.
        """
        if not (0 <= x < self.width and 0 <= y < self.height):
            return float('inf')  # Out of bounds
        if (x, y) in self.static_obstacles:
            return float('inf')  # Static obstacle
        return self.terrain_costs.get((x, y), 1) # Default cost is 1

    def is_obstacle(self, x, y, current_time=0):
        """
        Checks if a given cell (x, y) is an obstacle at a specific time.
        Considers both static and dynamic obstacles.
        """
        if not (0 <= x < self.width and 0 <= y < self.height):
            return True # Out of bounds
        if (x, y) in self.static_obstacles:
            return True # Static obstacle
        if (x, y) in self.dynamic_obstacles_schedule[current_time]:
            return True # Dynamic obstacle at current time
        return False

    def get_neighbors(self, x, y):
        """
        Returns a list of valid 4-connected neighbor coordinates for a given cell.
        """
        neighbors = []
        for dx, dy in [(0, 1), (0, -1), (1, 0), (-1, 0)]: # 4-connected movement
            nx, ny = x + dx, y + dy
            if 0 <= nx < self.width and 0 <= ny < self.height:
                neighbors.append((nx, ny))
        return neighbors

    @staticmethod
    def from_map_file(filepath):
        """
        Loads a GridEnvironment from a text-based map file.
        Map format:
            '#' for static obstacles
            '.' for default terrain cost 1
            Digits '1'-'9' for specific terrain costs
            'S' for start (ignored for environment model, handled by agent)
            'G' for goal (ignored for environment model, handled by agent)
        """
        with open(filepath, 'r') as f:
            lines = f.readlines()

        height = len(lines)
        width = len(lines[0].strip())
        
        terrain_costs = {}
        static_obstacles = set()
        
        for y, line in enumerate(lines):
            for x, char in enumerate(line.strip()):
                if char == '#':
                    static_obstacles.add((x, y))
                elif char.isdigit():
                    terrain_costs[(x, y)] = int(char)
                # Assuming '.' or other characters are default cost 1
                # 'S' and 'G' are handled by the agent, not the environment model itself

        return GridEnvironment(width, height, terrain_costs, static_obstacles)

    def add_dynamic_obstacle_movement(self, obstacle_id, path, start_time):
        """
        Adds a dynamic obstacle's movement schedule to the environment.
        
        Args:
            obstacle_id (str): A unique identifier for the dynamic obstacle.
            path (list): A list of (x, y) tuples representing the obstacle's movement path.
            start_time (int): The time at which the obstacle starts moving.
        """
        for i, (x, y) in enumerate(path):
            self.dynamic_obstacles_schedule[start_time + i].add((x, y))

    def __str__(self):
        """
        Returns a string representation of the grid environment (static view).
        """
        grid_str = ""
        for y in range(self.height):
            line = ""
            for x in range(self.width):
                if (x, y) in self.static_obstacles:
                    line += "#"
                elif (x, y) in self.terrain_costs:
                    line += str(self.terrain_costs[(x, y)])
                else:
                    line += "."
            grid_str += line + "\n"
        return grid_str
