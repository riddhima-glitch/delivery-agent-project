"use client"

import { useState, useEffect } from "react"
import { GridVisualization } from "@/components/grid-visualization"
import { ControlPanel } from "@/components/control-panel"

interface SimulationResult {
  path: { x: number; y: number }[]
  cost: number
  nodesExpanded: number
  timeTaken: number
  staticObstacles: { x: number; y: number }[]
  gridData: number[][]
  dynamicObstacles: { x: number; y: number; time: number }[]
}

export default function Home() {
  const [currentMap, setCurrentMap] = useState("small_map")
  const [currentAlgorithm, setCurrentAlgorithm] = useState("UCS")
  const [startCoords, setStartCoords] = useState("0,0")
  const [goalCoords, setGoalCoords] = useState("14,14")
  const [dynamicReplanningEnabled, setDynamicReplanningEnabled] = useState(false)

  const [simulationResult, setSimulationResult] = useState<SimulationResult | null>(null)
  const [agentCurrentPosition, setAgentCurrentPosition] = useState<{ x: number; y: number } | undefined>(undefined)
  const [currentPathSegment, setCurrentPathSegment] = useState<{ x: number; y: number }[]>([])
  const [currentTime, setCurrentTime] = useState(0)
  const [isSimulating, setIsSimulating] = useState(false)

  useEffect(() => {
    if (!isSimulating || !simulationResult || simulationResult.path.length === 0) {
      return
    }

    const path = simulationResult.path
    let stepIndex = 0

    const interval = setInterval(() => {
      if (stepIndex < path.length) {
        setAgentCurrentPosition(path[stepIndex])
        setCurrentPathSegment(path.slice(stepIndex))
        setCurrentTime(stepIndex)
        stepIndex++
      } else {
        setIsSimulating(false)
        clearInterval(interval)
      }
    }, 500)

    return () => clearInterval(interval)
  }, [isSimulating, simulationResult])

  const handleMapSelect = (mapName: string) => {
    setCurrentMap(mapName)
    setSimulationResult(null)
    setAgentCurrentPosition(undefined)
    setCurrentPathSegment([])
    setCurrentTime(0)
    setIsSimulating(false)
  }

  const handleAlgorithmSelect = (algorithm: string) => {
    setCurrentAlgorithm(algorithm)
    setDynamicReplanningEnabled(algorithm === "LOCAL_SEARCH")
    setSimulationResult(null)
    setAgentCurrentPosition(undefined)
    setCurrentPathSegment([])
    setCurrentTime(0)
    setIsSimulating(false)
  }

  const handleStartChange = (start: string) => {
    setStartCoords(start)
  }

  const handleGoalChange = (goal: string) => {
    setGoalCoords(goal)
  }

  const handleSimulate = async () => {
    setIsSimulating(true)
    setSimulationResult(null)
    setAgentCurrentPosition(undefined)
    setCurrentPathSegment([])
    setCurrentTime(0)

    try {
      const response = await fetch("/api/simulate", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          map: currentMap,
          algorithm: currentAlgorithm,
          start: startCoords,
          goal: goalCoords,
          dynamicReplanning: dynamicReplanningEnabled,
        }),
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || "Simulation failed")
      }

      const data: SimulationResult = await response.json()
      console.log("[v0] Simulation results:", data)
      setSimulationResult(data)
      if (data.path.length > 0) {
        setAgentCurrentPosition(data.path[0])
      }
    } catch (error: any) {
      console.error("[v0] Error running simulation:", error.message)
      alert(`Error: ${error.message}`)
      setIsSimulating(false)
    }
  }

  const handleToggleDynamicReplanning = (checked: boolean) => {
    setDynamicReplanningEnabled(checked)
  }

  return (
    <main className="flex min-h-screen flex-col items-center justify-center p-4 md:p-8 bg-background text-foreground">
      <h1 className="text-4xl md:text-5xl font-bold mb-8 text-center text-balance">Autonomous Delivery Agent</h1>
      <div className="flex flex-col md:flex-row gap-8 w-full max-w-6xl">
        <div className="md:w-1/2 flex justify-center">
          {simulationResult?.gridData ? (
            <GridVisualization
              gridData={simulationResult.gridData}
              staticObstacles={simulationResult.staticObstacles}
              agentPosition={agentCurrentPosition}
              path={currentPathSegment}
              dynamicObstacles={simulationResult.dynamicObstacles}
              currentTime={currentTime}
            />
          ) : (
            <GridVisualization gridData={Array.from({ length: 15 }, () => Array.from({ length: 15 }, () => 1))} />
          )}
        </div>
        <div className="md:w-1/2 flex justify-center">
          <ControlPanel
            onMapSelect={handleMapSelect}
            onAlgorithmSelect={handleAlgorithmSelect}
            onStartChange={handleStartChange}
            onGoalChange={handleGoalChange}
            onSimulate={handleSimulate}
            onToggleDynamicReplanning={handleToggleDynamicReplanning}
            dynamicReplanningEnabled={dynamicReplanningEnabled}
            currentMap={currentMap}
            currentAlgorithm={currentAlgorithm}
            startCoords={startCoords}
            goalCoords={goalCoords}
          />
        </div>
      </div>
      {simulationResult && (
        <div className="mt-8 p-4 bg-card rounded-lg shadow-lg w-full max-w-4xl">
          <h2 className="text-2xl font-bold mb-4 text-center">Simulation Results</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
            <div>
              <p className="text-muted-foreground">Path Cost</p>
              <p className="text-xl font-semibold">{simulationResult.cost.toFixed(2)}</p>
            </div>
            <div>
              <p className="text-muted-foreground">Nodes Expanded</p>
              <p className="text-xl font-semibold">{simulationResult.nodesExpanded}</p>
            </div>
            <div>
              <p className="text-muted-foreground">Time Taken (s)</p>
              <p className="text-xl font-semibold">{simulationResult.timeTaken.toFixed(4)}</p>
            </div>
          </div>
        </div>
      )}
      <p className="mt-4 text-center">Current Time: {currentTime}</p>
    </main>
  )
}
