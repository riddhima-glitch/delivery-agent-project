import { NextResponse } from "next/server"
import { spawn } from "child_process"

export async function POST(request: Request) {
  try {
    const { map, algorithm, start, goal, dynamicReplanning } = await request.json()

    const startCoords = start.split(",").map(Number)
    const goalCoords = goal.split(",").map(Number)

    if (startCoords.length !== 2 || goalCoords.length !== 2) {
      return NextResponse.json(
        { error: 'Invalid start or goal coordinates. Please use "x,y" format.' },
        { status: 400 },
      )
    }

    const pythonArgs = [
      "main.py",
      algorithm,
      "--map",
      `maps/${map}.txt`,
      "--start",
      `${startCoords[0]},${startCoords[1]}`,
      "--goal",
      `${goalCoords[0]},${goalCoords[1]}`,
    ]

    if (dynamicReplanning && algorithm === "LOCAL_SEARCH") {
      pythonArgs.push("--dynamic-replanning")
    }

    console.log("[v0] Executing Python with args:", pythonArgs)

    const pythonProcess = spawn("python", pythonArgs, { cwd: process.cwd() })

    let stdout = ""
    let stderr = ""

    pythonProcess.stdout.on("data", (data) => {
      stdout += data.toString()
    })

    pythonProcess.stderr.on("data", (data) => {
      stderr += data.toString()
    })

    const result = await new Promise((resolve, reject) => {
      pythonProcess.on("close", (code) => {
        if (code !== 0) {
          console.error("[v0] Python script exited with error:", stderr)
          return reject(new Error(`Python script error: ${stderr}`))
        }
        resolve(stdout)
      })
      pythonProcess.on("error", (err) => {
        console.error("[v0] Failed to start Python process:", err)
        reject(new Error(`Failed to start Python process: ${err.message}`))
      })
    })

    // Parse the output from the Python script
    const lines = (result as string).split("\n")
    let path: { x: number; y: number }[] = []
    let cost: number | null = null
    let nodesExpanded: number | null = null
    let timeTaken: number | null = null
    let staticObstacles: { x: number; y: number }[] = []
    let gridData: number[][] = []
    let dynamicObstacles: { x: number; y: number; time: number }[] = []

    lines.forEach((line) => {
      if (line.startsWith("Path:")) {
        path = JSON.parse(line.substring(line.indexOf(":") + 1).trim())
      } else if (line.startsWith("Cost:")) {
        cost = Number.parseFloat(line.substring(line.indexOf(":") + 1).trim())
      } else if (line.startsWith("Nodes Expanded:")) {
        nodesExpanded = Number.parseInt(line.substring(line.indexOf(":") + 1).trim())
      } else if (line.startsWith("Time Taken:")) {
        timeTaken = Number.parseFloat(line.substring(line.indexOf(":") + 1).trim())
      } else if (line.startsWith("Static Obstacles:")) {
        staticObstacles = JSON.parse(line.substring(line.indexOf(":") + 1).trim())
      } else if (line.startsWith("Grid Data:")) {
        gridData = JSON.parse(line.substring(line.indexOf(":") + 1).trim())
      } else if (line.startsWith("Dynamic Obstacles:")) {
        dynamicObstacles = JSON.parse(line.substring(line.indexOf(":") + 1).trim())
      }
    })

    return NextResponse.json({ path, cost, nodesExpanded, timeTaken, staticObstacles, gridData, dynamicObstacles })
  } catch (error: any) {
    console.error("[v0] API Error:", error.message)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
