import random
import os
from grid_environment import GridEnvironment

def generate_random_map(width, height, obstacle_density=0.2, max_terrain_cost=5):
    """
    Generates a random grid environment with static obstacles and varying terrain costs.

    Args:
        width (int): The width of the map.
        height (int): The height of the map.
        obstacle_density (float): The probability of a cell being a static obstacle (0.0 to 1.0).
        max_terrain_cost (int): The maximum terrain cost for non-obstacle cells.

    Returns:
        GridEnvironment: A new GridEnvironment instance.
    """
    terrain_costs = {}
    static_obstacles = set()

    for y in range(height):
        for x in range(width):
            if random.random() < obstacle_density:
                static_obstacles.add((x, y))
            else:
                terrain_costs[(x, y)] = random.randint(1, max_terrain_cost)
    
    return GridEnvironment(width, height, terrain_costs, static_obstacles)

def save_map_to_file(environment, filepath):
    """
    Saves a GridEnvironment to a text file.
    """
    with open(filepath, 'w') as f:
        for y in range(environment.height):
            line = ""
            for x in range(environment.width):
                if (x, y) in environment.static_obstacles:
                    line += "#"
                elif (x, y) in environment.terrain_costs:
                    line += str(environment.terrain_costs[(x, y)])
                else:
                    line += "."
            f.write(line + "\n")

def create_test_maps():
    """
    Generates and saves a set of predefined test maps (small, medium, large, dynamic).
    """
    # Ensure the maps directory exists
    if not os.path.exists("maps"):
        os.makedirs("maps")

    # Small map
    small_env = generate_random_map(10, 10, obstacle_density=0.1)
    save_map_to_file(small_env, "maps/small_map.txt")

    # Medium map
    medium_env = generate_random_map(20, 20, obstacle_density=0.15)
    save_map_to_file(medium_env, "maps/medium_map.txt")

    # Large map
    large_env = generate_random_map(50, 50, obstacle_density=0.2)
    save_map_to_file(large_env, "maps/large_map.txt")

    # Dynamic obstacle map
    dynamic_env = GridEnvironment(15, 15)
    # Add some static obstacles to create a more interesting path
    dynamic_env.static_obstacles.add((2,2))
    dynamic_env.static_obstacles.add((3,2))
    dynamic_env.static_obstacles.add((4,2))
    dynamic_env.static_obstacles.add((4,3))
    dynamic_env.static_obstacles.add((4,4))
    dynamic_env.static_obstacles.add((3,4))
    dynamic_env.static_obstacles.add((2,4))

    # Moving vehicle 1
    dynamic_env.add_dynamic_obstacle_movement("car1", [(0,0), (1,0), (2,0), (3,0), (4,0), (5,0)], 1)
    dynamic_env.add_dynamic_obstacle_movement("car1", [(5,0), (5,1), (5,2), (5,3), (5,4)], 6)

    # Moving vehicle 2
    dynamic_env.add_dynamic_obstacle_movement("car2", [(14,14), (13,14), (12,14), (11,14), (10,14)], 2)
    dynamic_env.add_dynamic_obstacle_movement("car2", [(10,14), (10,13), (10,12), (10,11), (10,10)], 7)

    save_map_to_file(dynamic_env, "maps/dynamic_map.txt")

if __name__ == "__main__":
    create_test_maps()
    print("Test maps generated in the 'maps' directory.")
