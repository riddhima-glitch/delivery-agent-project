import unittest
import os
from grid_environment import GridEnvironment
from delivery_agent import DeliveryAgent, State
from search_algorithms import uniform_cost_search, a_star_search, manhattan_distance_heuristic, hill_climbing_replanning

class TestDeliveryAgent(unittest.TestCase):

    def setUp(self):
        # Create a simple test map
        self.test_map_content = [
            "S.1#",
            ".2..",
            "#.3G"
        ]
        self.test_map_filepath = "maps/test_map.txt"
        if not os.path.exists("maps"):
            os.makedirs("maps")
        with open(self.test_map_filepath, "w") as f:
            for line in self.test_map_content:
                f.write(line + "\n")

        self.environment = GridEnvironment.from_map_file(self.test_map_filepath)
        self.agent = DeliveryAgent(self.environment, (0,0), (3,2)) # S at (0,0), G at (3,2)

    def tearDown(self):
        if os.path.exists(self.test_map_filepath):
            os.remove(self.test_map_filepath)
        # Clean up maps directory if empty, or just leave it for other tests
        if not os.listdir("maps"):
            os.rmdir("maps")

    def test_environment_loading(self):
        self.assertEqual(self.environment.width, 4)
        self.assertEqual(self.environment.height, 3)
        self.assertIn((3,0), self.environment.static_obstacles)
        self.assertEqual(self.environment.get_cost(2,0), 1)
        self.assertEqual(self.environment.get_cost(1,1), 2)
        self.assertEqual(self.environment.get_cost(2,2), 3)

    def test_agent_initial_state_and_goal(self):
        initial_state = self.agent.get_initial_state()
        self.assertEqual(initial_state, State(x=0, y=0, time=0))
        self.assertTrue(self.agent.is_goal(State(x=3, y=2, time=5)))
        self.assertFalse(self.agent.is_goal(State(x=0, y=0, time=0)))

    def test_agent_actions_and_cost(self):
        # From (0,0) at time 0
        actions = self.agent.get_actions(State(x=0, y=0, time=0))
        # Possible moves: (1,0) cost 1, (0,1) cost 1
        # (0,0) -> (1,0) at time 1, cost 1
        # (0,0) -> (0,1) at time 1, cost 1
        self.assertIn(State(x=1, y=0, time=1), actions)
        self.assertIn(State(x=0, y=1, time=1), actions)
        self.assertEqual(len(actions), 2) # Cannot move to (0,-1) or (-1,0)

        self.assertEqual(self.agent.get_cost(State(x=0,y=0,time=0), State(x=1,y=0,time=1)), 1)
        self.assertEqual(self.agent.get_cost(State(x=0,y=0,time=0), State(x=0,y=1,time=1)), 1)
        self.assertEqual(self.agent.get_cost(State(x=1,y=1,time=1), State(x=1,y=0,time=2)), 1) # Moving to '.'
        self.assertEqual(self.agent.get_cost(State(x=1,y=1,time=1), State(x=2,y=1,time=2)), 1) # Moving to '.'
        self.assertEqual(self.agent.get_cost(State(x=1,1,time=1), State(x=1,2,time=2)), float('inf')) # Moving to '#'

    def test_uniform_cost_search(self):
        path, cost, nodes = uniform_cost_search(self.agent)
        self.assertIsNotNone(path)
        self.assertLess(cost, float('inf'))
        # Expected path and cost for the simple map (manual calculation)
        # S(0,0) -> (0,1) -> (1,1) -> (2,1) -> (2,2) -> (3,2)G
        # Costs: 1 + 2 + 1 + 3 + 1 = 8
        self.assertEqual(cost, 8)
        self.assertEqual(path[-1].x, 3)
        self.assertEqual(path[-1].y, 2)

    def test_a_star_search(self):
        path, cost, nodes = a_star_search(self.agent, manhattan_distance_heuristic)
        self.assertIsNotNone(path)
        self.assertLess(cost, float('inf'))
        self.assertEqual(cost, 8) # Should find the same optimal path as UCS
        self.assertEqual(path[-1].x, 3)
        self.assertEqual(path[-1].y, 2)

    def test_dynamic_obstacles(self):
        dynamic_env = GridEnvironment(5, 5)
        dynamic_env.add_dynamic_obstacle_movement("car", [(1,1), (1,2)], 1) # Obstacle at (1,1) at time 1, (1,2) at time 2
        dynamic_agent = DeliveryAgent(dynamic_env, (0,0), (4,4))

        # Path should avoid (1,1) at time 1 and (1,2) at time 2
        path, cost, nodes = a_star_search(dynamic_agent, manhattan_distance_heuristic)
        self.assertIsNotNone(path)
        self.assertLess(cost, float('inf'))
        
        # Verify path does not hit dynamic obstacles
        for state in path:
            self.assertFalse(dynamic_env.is_obstacle(state.x, state.y, state.time))

    def test_hill_climbing_replanning(self):
        # For hill climbing, it's harder to assert specific path/cost due to randomness
        # We'll assert that it attempts to find a path and doesn't crash
        # And if a path is found, its cost is not infinite
        path, cost, nodes = hill_climbing_replanning(self.agent, self.agent.get_initial_state())
        
        # Hill climbing might not always find the optimal path or even any path in complex scenarios
        # But for a simple map, it should find a path.
        if path:
            self.assertLess(cost, float('inf'))
            self.assertTrue(self.agent.is_goal(path[-1]))
        else:
            print("Hill climbing did not find a path in this test run (expected for some random seeds).")


if __name__ == '__main__':
    unittest.main()
