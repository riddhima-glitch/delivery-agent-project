import subprocess
import json
import os

def run_command(command):
    """
    Executes a shell command and returns its stdout.
    """
    try:
        result = subprocess.run(command, shell=True, capture_output=True, text=True, check=True)
        return result.stdout
    except subprocess.CalledProcessError as e:
        print(f"Error running command: {command}")
        print(f"Stdout: {e.stdout}")
        print(f"Stderr: {e.stderr}")
        return None

def parse_output(output):
    """
    Parses the output from main.py to extract relevant metrics.
    """
    if not output:
        return None
    
    cost = float('inf')
    nodes_expanded = 0
    time_taken = 0.0
    path_found = False

    for line in output.split('\n'):
        if "Total Cost:" in line:
            cost = float(line.split(":")[1].strip())
            path_found = True
        elif "Nodes Expanded:" in line:
            nodes_expanded = int(line.split(":")[1].strip())
        elif "Time Taken:" in line:
            time_taken = float(line.split(":")[1].replace("seconds", "").strip())
    
    return {"path_found": path_found, "cost": cost, "nodes_expanded": nodes_expanded, "time_taken": time_taken}

def main():
    """
    Main function to run experiments across different maps and planners.
    """
    maps = {
        "small_map": {"path": "maps/small_map.txt", "start": "0,0", "goal": "9,9"},
        "medium_map": {"path": "maps/medium_map.txt", "start": "0,0", "goal": "19,19"},
        "large_map": {"path": "maps/large_map.txt", "start": "0,0", "goal": "49,49"},
        "dynamic_map": {"path": "maps/dynamic_map.txt", "start": "0,0", "goal": "14,14"}
    }
    planners = ["UCS", "A*", "LocalSearch"]
    
    results = {}

    # Ensure maps directory exists and maps are generated
    if not os.path.exists("maps"):
        print("Maps directory not found. Generating maps...")
        subprocess.run(["python", "map_generator.py"])

    for map_name, map_info in maps.items():
        results[map_name] = {}
        for planner in planners:
            command = f"python main.py {planner} --map {map_info['path']} --start {map_info['start']} --goal {map_info['goal']}"
            
            if planner == "LocalSearch" and map_name == "dynamic_map":
                command += " --dynamic-replanning"
            
            print(f"Running: {command}")
            output = run_command(command)
            parsed_results = parse_output(output)
            results[map_name][planner] = parsed_results
            print(f"  -> {parsed_results}")

    print("\n--- Experiment Results ---")
    print(json.dumps(results, indent=2))

    # Optional: Further analysis and plotting can be added here.
    # For the report, this JSON output can be converted into tables and plots.

if __name__ == "__main__":
    main()
