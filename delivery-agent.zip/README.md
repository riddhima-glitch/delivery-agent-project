# Autonomous Delivery Agent

This project implements an autonomous delivery agent that navigates a 2D grid city to deliver packages. It includes different search algorithms to find optimal or near-optimal paths, considering static obstacles, varying terrain costs, and dynamic moving obstacles.

## Features

- **Environment Modeling**: Represents a 2D grid city with configurable width, height, terrain costs, static obstacles, and dynamic obstacle schedules.
- **Rational Agent**: Chooses actions to maximize delivery efficiency under constraints.
- **Search Algorithms**:
    - **Uninformed Search**: Uniform-Cost Search (UCS)
    - **Informed Search**: A* Search with Manhattan distance heuristic
    - **Local Search Replanning**: Hill-Climbing with random restarts for dynamic environments.
- **Map Generation**: Utility to create small, medium, large, and dynamic test maps.
- **Command-Line Interface (CLI)**: To run each planner on specified maps and start/goal positions.
- **Dynamic Replanning Proof-of-Concept**: Demonstrates the agent's ability to adapt to new obstacles appearing during execution.
- **Experimental Comparison**: Script to run all planners on various maps and report performance metrics.

## Project Structure

\`\`\`
.
├── grid_environment.py         # Defines the GridEnvironment class
├── delivery_agent.py           # Defines the DeliveryAgent and State classes
├── search_algorithms.py        # Implements UCS, A*, and Local Search algorithms
├── map_generator.py            # Generates test map files
├── main.py                     # CLI to run planners and simulations
├── run_experiments.py          # Script to automate experiments and report results
├── test_delivery_agent.py      # Unit tests for core functionalities
└── maps/                       # Directory to store generated map files
    ├── small_map.txt
    ├── medium_map.txt
    ├── large_map.txt
    └── dynamic_map.txt
\`\`\`

## Setup and Installation

1.  **Clone the repository:**
    \`\`\`bash
    git clone <repository-url>
    cd autonomous-delivery-agent
    \`\`\`

2.  **Install dependencies:**
    This project uses standard Python libraries. No special `pip install` is required beyond a standard Python 3 installation.

## Usage

### 1. Generate Maps

First, generate the test maps:

\`\`\`bash
python map_generator.py
\`\`\`

This will create a `maps/` directory containing `small_map.txt`, `medium_map.txt`, `large_map.txt`, and `dynamic_map.txt`.

### 2. Run Planners via CLI

You can run individual planners using `main.py`.

**Syntax:**
\`\`\`bash
python main.py <planner_name> --map <map_filepath> --start <x,y> --goal <x,y> [--dynamic-replanning]
\`\`\`

-   `<planner_name>`: `UCS`, `A*`, or `LocalSearch`
-   `<map_filepath>`: Path to a map file (e.g., `maps/small_map.txt`)
-   `<x,y>`: Comma-separated coordinates for start and goal positions.
-   `--dynamic-replanning`: (Optional) Use with `LocalSearch` to simulate dynamic obstacle appearance and replanning.

**Examples:**

-   **Run Uniform-Cost Search on a small map:**
    \`\`\`bash
    python main.py UCS --map maps/small_map.txt --start 0,0 --goal 9,9
    \`\`\`

-   **Run A* Search on a medium map:**
    \`\`\`bash
    python main.py A* --map maps/medium_map.txt --start 0,0 --goal 19,19
    \`\`\`

-   **Run Local Search (single plan attempt) on a large map:**
    \`\`\`bash
    python main.py LocalSearch --map maps/large_map.txt --start 0,0 --goal 49,49
    \`\`\`

### 3. Dynamic Replanning Proof-of-Concept

To see the agent replan in response to a new dynamic obstacle:

\`\`\`bash
python main.py LocalSearch --map maps/dynamic_map.txt --start 0,0 --goal 14,14 --dynamic-replanning
\`\`\`

Observe the `[LOG]` messages in the output, indicating when a new obstacle appears and when replanning is triggered.

### 4. Run Experiments

To run all planners on the predefined test maps and get a summary of results:

\`\`\`bash
python run_experiments.py
\`\`\`

This script will output a JSON summary of path cost, nodes expanded, and time taken for each planner on each map.

## Tests

To run the unit tests:

\`\`\`bash
python -m unittest test_delivery_agent.py
\`\`\`

## Report and Demo

A short report (max 6 pages) and a 5-minute recorded demo/sequence of screenshots are required deliverables. These should cover:

-   Environment model
-   Agent design
-   Heuristics used
-   Experimental results (tables + short plots)
-   Analysis describing when each method performs better and why
-   Visual demonstration of dynamic replanning.

## Assumptions

-   Grid cells have integer movement cost $\ge 1$.
-   Agent can move 4-connected (up/down/left/right).
-   Moving obstacles occupy cells and move deterministically according to a known schedule (for UCS/A* planning horizon) or unpredictably (for local search testing).
