import argparse
import time
import os
import json # Import json module

from grid_environment import GridEnvironment
from delivery_agent import DeliveryAgent, State
from search_algorithms import uniform_cost_search, a_star_search, manhattan_distance_heuristic, hill_climbing_replanning


def run_planner(planner_name, environment_filepath, start_x, start_y, goal_x, goal_y, dynamic_replanning=False):
    """
    Runs a specified planning algorithm and reports its performance in JSON format.
    """
    # print(f"--- Running {planner_name} ---")
    # print(f"Map: {environment_filepath}")
    # print(f"Start: ({start_x}, {start_y}), Goal: ({goal_x}, {goal_y})")

    environment = GridEnvironment.from_map_file(environment_filepath)
    
    # If it's a dynamic map, load dynamic obstacles
    if "dynamic_map.txt" in environment_filepath:
        dynamic_env_temp = GridEnvironment(15, 15)
        dynamic_env_temp.add_dynamic_obstacle_movement("car1", [(0,0), (1,0), (2,0), (3,0), (4,0), (5,0)], 1)
        dynamic_env_temp.add_dynamic_obstacle_movement("car1", [(5,0), (5,1), (5,2), (5,3), (5,4)], 6)
        dynamic_env_temp.add_dynamic_obstacle_movement("car2", [(14,14), (13,14), (12,14), (11,14), (10,14)], 2)
        dynamic_env_temp.add_dynamic_obstacle_movement("car2", [(10,14), (10,13), (10,12), (10,11), (10,10)], 7)
        environment.dynamic_obstacles_schedule = dynamic_env_temp.dynamic_obstacles_schedule


    agent = DeliveryAgent(environment, (start_x, start_y), (goal_x, goal_y))

    path = None
    cost = float('inf')
    nodes_expanded = 0
    start_time = time.time()

    results = {
        "path": [],
        "cost": float('inf'),
        "nodesExpanded": 0,
        "timeTaken": 0.0,
        "staticObstacles": [{"x": ox, "y": oy} for ox, oy in environment.static_obstacles],
        "gridData": environment.grid, # Assuming environment.grid is a 2D list of terrain costs
        "dynamicObstacles": []
    }

    for time_step, obstacles_at_time in environment.dynamic_obstacles_schedule.items():
        for ox, oy in obstacles_at_time:
            results["dynamicObstacles"].append({"x": ox, "y": oy, "time": time_step})


    if planner_name == "UCS":
        path, cost, nodes_expanded = uniform_cost_search(agent)
    elif planner_name == "A*":
        path, cost, nodes_expanded = a_star_search(agent, manhattan_distance_heuristic)
    elif planner_name == "LocalSearch":
        if not dynamic_replanning:
            # print("Local Search is primarily for dynamic replanning. Running a single plan attempt.")
            path, cost, nodes_expanded = hill_climbing_replanning(agent, agent.get_initial_state())
        else:
            # print("Running Local Search with dynamic replanning simulation...")
            current_state = agent.get_initial_state()
            simulated_path = [current_state]
            total_simulated_cost = 0
            total_nodes_expanded = 0
            
            for step in range(20):
                # print(f"\n--- Agent at time {current_state.time}, position ({current_state.x}, {current_state.y}) ---")
                
                if current_state.time == 5 and "dynamic_map.txt" in environment_filepath:
                    new_obstacle_pos = (7,7)
                    # print(f"[LOG] Dynamic obstacle appears at {new_obstacle_pos} at time {current_state.time + 1}!")
                    environment.dynamic_obstacles_schedule[current_state.time + 1].add(new_obstacle_pos)
                
                # print("[LOG] Replanning...")
                replan_path, replan_cost, replan_nodes = hill_climbing_replanning(agent, current_state)
                total_nodes_expanded += replan_nodes

                if replan_path is None:
                    # print("Replanning failed! Agent stuck.")
                    path = simulated_path
                    cost = float('inf')
                    break
                
                next_step_state = replan_path[1] if len(replan_path) > 1 else replan_path[0]
                
                move_cost = agent.get_cost(current_state, next_step_state)
                total_simulated_cost += move_cost
                simulated_path.append(next_step_state)
                current_state = next_step_state
                
                if agent.is_goal(current_state):
                    # print("Agent reached goal!")
                    path = simulated_path
                    cost = total_simulated_cost
                    break
            else:
                # print("Simulation ended before reaching goal.")
                path = simulated_path
                cost = total_simulated_cost
            nodes_expanded = total_nodes_expanded
    else:
        # print("Invalid planner name.")
        pass # No return, will output error in JSON

    end_time = time.time()
    time_taken = end_time - start_time

    if path:
        results["path"] = [{"x": s.x, "y": s.y} for s in path] # Convert path to list of dicts
        results["cost"] = cost
    else:
        results["path"] = []
        results["cost"] = float('inf') # Ensure cost is inf if no path

    results["nodesExpanded"] = nodes_expanded
    results["timeTaken"] = time_taken

    print(json.dumps(results))


def main():
    """
    Main function to parse arguments and run the selected planner.
    """
    parser = argparse.ArgumentParser(description="Autonomous Delivery Agent Planner")
    parser.add_argument("planner", type=str, choices=["UCS", "A*", "LocalSearch"], help="Choose a planning algorithm: UCS, A*, LocalSearch")
    parser.add_argument("--map", type=str, default="maps/small_map.txt", help="Path to the map file (e.g., maps/small_map.txt)")
    parser.add_argument("--start", type=str, default="0,0", help="Start coordinates (x,y)")
    parser.add_argument("--goal", type=str, default="9,9", help="Goal coordinates (x,y)")
    parser.add_argument("--dynamic-replanning", action="store_true", help="Enable dynamic replanning for LocalSearch")

    args = parser.parse_args()

    start_coords = tuple(map(int, args.start.split(',')))
    goal_coords = tuple(map(int, args.goal.split(',')))

    if not os.path.exists(args.map):
        print(json.dumps({"error": f"Map file '{args.map}' not found."}))
        return

    run_planner(args.planner, args.map, start_coords[0], start_coords[1], goal_coords[0], goal_coords[1], args.dynamic_replanning)

if __name__ == "__main__":
    main()
